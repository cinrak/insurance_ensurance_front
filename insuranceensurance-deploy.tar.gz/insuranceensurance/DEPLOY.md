# Deploying insuranceensurance to a test device

Layout in this archive (app.py auto-discovers the harness from this layout):

    insuranceensurance/
      backend/   Flask app (app.py, requirements.txt, static/ = built Vue UI)
      harness/   document engine (initial.py) + tests (verify_suite.py)

## Requirements on the device
- Python 3.10+ (3.11 recommended)
- On Apple Silicon Mac (AFM on-device model): macOS 26/27 + Xcode installed
  (the apple_fm_sdk wheel builds against the system Foundation Models)
- On any Linux/PC test device: no special hardware; add a local runner
  (ollama pull llama3) or use cloud model with a user key

## Setup (both platforms)

    tar xzf insuranceensurance-deploy.tar.gz && cd insuranceensurance
    python3 -m venv .venv
    .venv/bin/pip install -r backend/requirements.txt
    # on Apple Silicon this also installs apple_fm_sdk automatically

## Run

    cd backend && ../.venv/bin/python app.py
    # serves UI + API on http://127.0.0.1:5000

Open http://127.0.0.1:5000 -> Upload page -> upload home_insurance1.pdf (included)
-> Home -> type "what does the contract cover?" -> Ask.
First answer runs extraction+embedding+model; repeats are served from the
persistent memory in harness/.cache/ (instant, no model call).

## Model routing recap
- Apple Silicon Mac: automatic on-device AFM, no key, no cost. Fallback if the
  SDK is unavailable: run `fm serve` in a Terminal (preinstalled macOS 27).
- Any other host: `export LOCAL_LLM_BASE_URL=http://localhost:11434/v1
  LOCAL_LLM_MODEL=llama3` and ask with {"model":"local"} in the JSON body.
- Cloud per user: send {"model":"gpt-4o-mini","api_key":"***"} in /api/ask;
  the key is used per request only and never stored server-side.

## Optional checks on the device
    cd harness && ../.venv/bin/python verify_suite.py     # 17 checks, no model needed
    ../.venv/bin/python -c "import sys; sys.path.insert(0,'.'); import initial; \
      print(initial.summarise(open('../backend/home_insurance1.pdf','rb').read()))"

## Updating instead of re-zipping (git route)
backend + frontend are ordinary git repos (github.com/otdot/insurance_ensurance_server
/ ..._front). Once app.py + requirements.txt are committed there and harness/ is
committed too (own repo or vendored into backend/harness/ + set HARNESS_DIR),
the test device only needs: git pull && pip install -r backend/requirements.txt &&
python backend/app.py.

## What is NOT in this archive (deliberately)
- .venv (device builds its own; torch is platform-specific)
- instance/insurance.db (test device starts with an empty store; upload the
  sample PDF to seed it; production data stays on the production machine)
- harness/.cache (rebuilds itself on first ask)
