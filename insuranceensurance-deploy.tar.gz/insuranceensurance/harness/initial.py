"""Insurance harness: document ingestion, RAG index, LLM summarise/ask.

Also holds a persistent local memory (harness .cache/) so quick fetching does
not redo PDF extraction / embedding / model calls: faiss index snapshots keyed
to the contract-store revision, plus cached summaries and answers that
auto-invalidate whenever contracts change.

Model routing (per project decision):
- On Apple Silicon Macs (M1 and newer) the harness uses the on-device Apple
  Foundation Model (AFM) natively via the official `apple_fm_sdk` (pip install
  apple_fm_sdk; needs Xcode installed + macOS 26+ + Python 3.10+). If the SDK
  is unavailable it falls back to the OpenAI-compatible loopback server of the
  pre-installed `fm` CLI (`fm serve`, http://127.0.0.1:1976/v1). No API key,
  no account, no cloud cost. LOCAL_LLM_BASE_URL can point at another runner
  (Ollama, mlx_lm.server, ...).
- Elsewhere (or when the user selects a cloud model in frontend settings) it
  uses OpenAI; the API key may come from the request (user-supplied) or
  OPENAI_API_KEY.
"""
import os
import glob
import hashlib
import json
import platform
import sqlite3
from pathlib import Path

from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import openai

# ── 1. Ingest & chunk ──────────────────────────────────────────────
def chunk_text(text, size=500, overlap=50):
    words = text.split()
    return [' '.join(words[i:i + size]) for i in range(0, len(words), size - overlap)]

def load_documents_from_text(content: str) -> list[dict]:
    """Ingest already-loaded text instead of scanning a directory."""
    chunks = []
    if len(content.strip()) < 50:
        raise ValueError("Document too short (<50 chars)")
    for i, c in enumerate(chunk_text(content)):
        chunks.append({'content': c, 'source': 'front', 'id': f"front_{i}"})
    return chunks

def load_documents(docs_dir: str) -> list[dict]:
    chunks = []
    for fp in glob.glob(os.path.join(docs_dir, "**/*"), recursive=True):
        if Path(fp).suffix.lower() not in ('.txt', '.md', '.py', '.rst', '.pdf'):
            continue
        try:
            if Path(fp).suffix.lower() == '.pdf':
                content = extract_pdf_text(Path(fp).read_bytes(), name=fp)
            else:
                content = open(fp, encoding='utf-8', errors='ignore').read()
            if len(content.strip()) < 50:
                continue
            for i, c in enumerate(chunk_text(content)):
                chunks.append({'content': c, 'source': fp, 'id': f"{Path(fp).stem}_{i}"})
        except Exception as e:
            print(f"Error reading {fp}: {e}")
    return chunks

# ── 1b. PDF + contract store ingestion ─────────────────────────────
DEFAULT_DB = Path(__file__).resolve().parent.parent / "backend" / "instance" / "insurance.db"

def extract_pdf_text(pdf_bytes: bytes, name: str = "document.pdf") -> str:
    """Pull text layer out of PDF bytes (pypdf). Scanned/image PDFs need OCR
    and are reported as such rather than silently returning nothing."""
    try:
        from pypdf import PdfReader
    except ImportError as e:
        raise RuntimeError("pypdf not installed (pip install pypdf)") from e
    import io
    reader = PdfReader(io.BytesIO(pdf_bytes))
    text = "\n\n".join((page.extract_text() or "") for page in reader.pages)
    if len(text.strip()) < 50:
        raise ValueError(f"{name}: no extractable text layer (scanned PDF needs OCR)")
    return text

def load_contracts_from_db(db_path=None, contract_id: int = None) -> list[dict]:
    """Read stored contract PDFs (backend SQLite) and return text chunks.
    Rows come from the contracts table the Flask app writes."""
    db = str(db_path or DEFAULT_DB)
    if not os.path.exists(db):
        raise FileNotFoundError(f"contract DB not found: {db}")
    chunks = []
    with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as conn:
        if contract_id is not None:
            rows = conn.execute(
                "SELECT id, filename, pdf_data FROM contracts WHERE id = ?", (contract_id,)
            ).fetchall()
            if not rows:
                raise ValueError(f"No contract with id {contract_id}")
        else:
            rows = conn.execute(
                "SELECT id, filename, pdf_data FROM contracts ORDER BY id"
            ).fetchall()
    for cid, fname, blob in rows:
        try:
            content = extract_pdf_text(blob, name=fname)
        except (ValueError, RuntimeError) as e:
            print(f"Skipping contract {cid} ({fname}): {e}")
            continue
        for i, c in enumerate(chunk_text(content)):
            chunks.append({'content': c, 'source': f"db:{cid}:{fname}", 'id': f"db{cid}_{i}"})
    return chunks

# ── 2. Embed & index ───────────────────────────────────────────────
embedder = None

def get_embedder():
    """Lazy-init the local sentence-transformer (384-dim). Deferred so the
    module imports without ML deps installed (e.g. pure PDF extraction)."""
    global embedder
    if embedder is None:
        embedder = SentenceTransformer('all-MiniLM-L6-v2')
    return embedder

def build_index_from_chunks(chunks: list[dict]):
    """Embed pre-built chunks and index them (shared by server + CLI paths)."""
    if not chunks:
        raise ValueError("No chunks to index")
    vectors = get_embedder().encode([c['content'] for c in chunks])
    index = faiss.IndexFlatL2(vectors.shape[1])
    index.add(np.array(vectors, dtype='float32'))
    return chunks, index

def build_chunks_from_text(content: str):
    chunks = load_documents_from_text(content)
    return build_index_from_chunks(chunks)

def build_chunks(docs_dir: str = './docs'):
    chunks = load_documents(docs_dir)
    if not chunks:
        raise ValueError(f"No documents found in {docs_dir}")
    return build_index_from_chunks(chunks)

# ── 3. Retrieve ────────────────────────────────────────────────────
def retrieve(query: str, k=3, chunks=None, index=None) -> list[dict]:
    if chunks is None or index is None:
        raise RuntimeError("Chunks and index must be provided")
    qv = get_embedder().encode([query])
    _, idx = index.search(np.array(qv, dtype='float32'), k)
    return [chunks[i] for i in idx[0]]

# ── 4. Generate ────────────────────────────────────────────────────
# Local LLM on macOS: native Apple Foundation Model first (apple_fm_sdk),
# then `fm serve` (OpenAI-compatible loopback, port 1976, model tiers
# "system" / "pcc"). Override with LOCAL_LLM_BASE_URL for other runners.
def _local_base_url() -> str:
    if os.getenv("LOCAL_LLM_BASE_URL"):
        return os.environ["LOCAL_LLM_BASE_URL"]
    if platform.system() == "Darwin":
        return "http://127.0.0.1:1976/v1"  # `fm serve` (pre-installed, macOS 27+)
    return "http://localhost:11434/v1"     # Ollama on other hosts

def _local_model() -> str:
    if os.getenv("LOCAL_LLM_MODEL"):
        return os.environ["LOCAL_LLM_MODEL"]
    return "system" if platform.system() == "Darwin" else "llama3"

def is_local_machine() -> bool:
    """Apple Silicon Mac with on-device model (AFM) capability."""
    return platform.system() == "Darwin" and platform.machine() == "arm64"

def _chat_apple_fm(messages: list[dict]) -> str:
    """Native on-device Apple Foundation Model via official python-apple-fm-sdk.
    Raises if the SDK/model is unavailable so the caller can fall back."""
    import asyncio
    import apple_fm_sdk as fm
    system = next((m["content"] for m in messages if m["role"] == "system"), "")
    prompt = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
    model = fm.SystemLanguageModel()
    available, reason = model.is_available()
    if not available:
        raise RuntimeError(f"Apple FM unavailable: {reason}")
    session = fm.LanguageModelSession(model=model, instructions=system) if system \
        else fm.LanguageModelSession(model=model)
    return str(asyncio.run(session.respond(prompt)))

def _chat_local(messages: list[dict]) -> str:
    """macOS: native AFM first, then OpenAI-compatible local runner
    (`fm serve` / Ollama / mlx). Other hosts: the configured local runner."""
    if platform.system() == "Darwin" and platform.machine() == "arm64":
        try:
            return _chat_apple_fm(messages)
        except ImportError:
            pass  # SDK not installed -> OpenAI-compatible endpoint
        except RuntimeError:
            pass  # model unavailable -> OpenAI-compatible endpoint
    client = openai.OpenAI(base_url=_local_base_url(), **{"api_key": "not-needed"})
    resp = client.chat.completions.create(model=_local_model(), messages=messages)
    return resp.choices[0].message.content

def _chat(messages: list[dict], model: str = "auto", api_key: str = None) -> str:
    want_local = model in (None, "", "local") or (model == "auto" and is_local_machine())
    if want_local:
        return _chat_local(messages)
    if model in (None, "", "auto", "local"):
        model = "gpt-4o-mini"
    resolved_key = api_key or os.getenv("OPENAI_API_KEY")
    if not resolved_key:
        raise ValueError("Cloud model requested but no API key (settings or OPENAI_API_KEY)")
    client = openai.OpenAI(base_url="https://api.openai.com/v1", **{"api_key": resolved_key})
    resp = client.chat.completions.create(model=model, messages=messages)
    return resp.choices[0].message.content

def summarise(document, model: str = "auto", api_key: str = None) -> str:
    """Summarise a document: plain text (frontend input) or PDF bytes
    (upload / stored contract). Local AFM by default on Apple Silicon."""
    if isinstance(document, (bytes, bytearray)):
        if b"%PDF-" not in document[:1024]:
            raise ValueError("binary input is not a PDF")
        document = extract_pdf_text(bytes(document))
    chunks, _ = build_chunks_from_text(document)
    context = '\n\n'.join(c['content'] for c in chunks)
    return _chat([
        {"role": "system",
         "content": "Summarise the document below concisely. If content is unclear, say 'I don't know'."},
        {"role": "user", "content": f"Document:\n{context}"}
    ], model, api_key)

def ask(question: str, chunks=None, index=None, model: str = "auto", api_key: str = None,
        with_sources: bool = False):
    """RAG query: answer from retrieved context only."""
    ctx = retrieve(question, chunks=chunks, index=index)
    context = '\n\n'.join(c['content'] for c in ctx)
    answer = _chat([
        {"role": "system",
         "content": "Answer based ONLY on the provided context. Say 'I don't know' if not found."},
        {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"}
    ], model, api_key)
    if with_sources:
        return answer, sorted({c["source"] for c in ctx})
    return answer

# ── 5. Persistent memory (quick fetch) ─────────────────────────────
CACHE_DIR = Path(os.getenv("HARNESS_CACHE_DIR",
                           Path(__file__).resolve().parent / ".cache"))

def contracts_revision(db_path=None) -> str:
    """Stable fingerprint of the contract store; any upload changes it."""
    db = str(db_path or DEFAULT_DB)
    with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as conn:
        rows = conn.execute("SELECT id, uploaded_at FROM contracts ORDER BY id").fetchall()
    return hashlib.sha1(repr(rows).encode()).hexdigest()[:16]

def _cache_conn():
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(CACHE_DIR / "harness_memory.sqlite3")
    conn.execute("""CREATE TABLE IF NOT EXISTS memory (
        key TEXT PRIMARY KEY, revision TEXT, value TEXT, created_at TEXT)""")
    return conn

def get_rag_index(db_path=None):
    """Cached RAG over the whole contract store: loads the persisted faiss
    index for the current revision, builds + persists it on miss."""
    rev = contracts_revision(db_path)
    idx_path = CACHE_DIR / f"index_{rev}.faiss"
    meta_path = CACHE_DIR / f"chunks_{rev}.json"
    if hasattr(faiss, "read_index") and idx_path.is_file() and meta_path.is_file():
        return json.loads(meta_path.read_text()), faiss.read_index(str(idx_path)), rev
    chunks = load_contracts_from_db(db_path)
    chunks, index = build_index_from_chunks(chunks)
    if hasattr(faiss, "write_index"):
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        faiss.write_index(index, str(idx_path))
        meta_path.write_text(json.dumps(chunks))
    return chunks, index, rev

def _cached_get(conn, key, rev):
    row = conn.execute("SELECT value FROM memory WHERE key=? AND revision=?",
                       (key, rev)).fetchone()
    return row[0] if row else None

def _cached_put(conn, key, rev, value):
    conn.execute("INSERT OR REPLACE INTO memory VALUES (?,?,?,datetime('now'))",
                 (key, rev, value))
    conn.commit()

def summarise_contract_cached(contract_id: int, model: str = "auto",
                              api_key: str = None, db_path=None, refresh: bool = False) -> dict:
    """Concise summary per stored contract, kept in persistent memory so
    repeat fetches cost nothing. Returns {"summary", "cache": hit|miss}."""
    rev = contracts_revision(db_path)
    conn = _cache_conn()
    key = f"summary:contract:{contract_id}"
    if not refresh:
        hit = _cached_get(conn, key, rev)
        if hit is not None:
            return {"summary": hit, "cache": "hit"}
    chunks = load_contracts_from_db(db_path, contract_id)
    doc = "\n\n".join(c["content"] for c in chunks)
    summary = summarise(doc, model, api_key)
    _cached_put(conn, key, rev, summary)
    return {"summary": summary, "cache": "miss"}

def ask_cached(question: str, model: str = "auto", api_key: str = None,
               db_path=None, refresh: bool = False) -> dict:
    """RAG question with persistent answer + index memory. Returns
    {"answer", "sources", "cache": hit|miss}. Sources = documents actually
    retrieved for this question, not the whole store."""
    chunks, index, rev = get_rag_index(db_path)
    conn = _cache_conn()
    norm = " ".join(question.lower().split())
    key = "ask:" + hashlib.sha1(f"{rev}|{norm}".encode()).hexdigest()
    if not refresh:
        hit = _cached_get(conn, key, rev)
        if hit is not None:
            srcs = sorted({c["source"] for c in retrieve(question, chunks=chunks, index=index)})
            return {"answer": hit, "sources": srcs, "cache": "hit"}
    answer, srcs = ask(question, chunks, index, model, api_key, with_sources=True)
    _cached_put(conn, key, rev, answer)
    return {"answer": answer, "sources": srcs, "cache": "miss"}

# ── Entry point ────────────────────────────────────────────────────
def main(docs_dir: str = './docs', question: str = "What is the refund policy?"):
    chunks, index = build_chunks(docs_dir)
    result = ask(question, chunks=chunks, index=index)
    print(result)
    return result

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Insurance harness: index docs and query.")
    parser.add_argument("--docs", default="./docs", help="Directory to scan for documents (txt/md/py/rst/pdf)")
    parser.add_argument("--question", default="What is the refund policy?", help="Query to run")
    parser.add_argument("--model", default="auto", help="'auto' (local on Apple Silicon), 'local', or e.g. 'gpt-4o-mini'")
    parser.add_argument("--pdf", help="Summarise a single PDF file instead of directory RAG")
    parser.add_argument("--contract-id", type=int, help="Summarise contract stored in backend DB (SQLite)")
    parser.add_argument("--db", help="Path to insurance.db (default: ../backend/instance/insurance.db)")
    args = parser.parse_args()
    if args.pdf:
        print(summarise(Path(args.pdf).read_bytes(), model=args.model))
    elif args.contract_id is not None:
        chunks = load_contracts_from_db(args.db, args.contract_id)
        doc = "\n\n".join(c['content'] for c in chunks)
        print(summarise(doc, model=args.model))
    else:
        chunks, index = build_chunks(args.docs)
        print(ask(args.question, chunks=chunks, index=index, model=args.model))
