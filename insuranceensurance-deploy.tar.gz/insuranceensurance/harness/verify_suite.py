"""Verification suite for insuranceensurance harness (runs with stubbed deps)."""
import sys, types, os, tempfile
os.environ["HARNESS_CACHE_DIR"] = tempfile.mkdtemp(prefix="suite_cache_")

def _array(x, dtype=None):
    if hasattr(x, "_data"): return x
    o = types.SimpleNamespace(); o._data = x
    if isinstance(x, list) and x and isinstance(x[0], list):
        o.shape = (len(x), len(x[0]))
    else:
        o.shape = (len(x),)
    return o

class FakeEmbedder:
    def encode(self, texts):
        return _array([[(abs(hash(t)) % 1000) / 1000.0] * 384 for t in texts])

st = types.ModuleType("sentence_transformers")
st.SentenceTransformer = lambda *a, **k: FakeEmbedder()
sys.modules["sentence_transformers"] = st
np = types.ModuleType("numpy"); np.array = _array; sys.modules["numpy"] = np

class FakeIndex:
    def __init__(self, dim): self.dim = dim; self.vs = []
    def add(self, vecs): self.vs.extend(vecs._data)
    def search(self, q, k): return None, [list(range(min(k, len(self.vs))))]
fa = types.ModuleType("faiss"); fa.IndexFlatL2 = FakeIndex; sys.modules["faiss"] = fa

seen = []
class FakeOpenAI:
    def __init__(self, base_url=None, **kw): self.base = base_url; self.kw = kw
    @property
    def chat(self):
        outer = self
        class C:
            class completions:
                @staticmethod
                def create(model, messages):
                    seen.append((outer.base, model, outer.kw.get("api_key")))
                    r = types.SimpleNamespace()
                    r.choices = [types.SimpleNamespace(message=types.SimpleNamespace(content="CLOUD-OK"))]
                    return r
        return C()
om = types.ModuleType("openai"); om.OpenAI = FakeOpenAI; sys.modules["openai"] = om

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import initial

DOC = "refund policy details " * 30
PROMPT_LEN = []
fm = types.ModuleType("apple_fm_sdk")
class SLM:
    def is_available(self): return (True, "")
class LMS:
    def __init__(self, model=None, instructions=""): pass
    async def respond(self, prompt): PROMPT_LEN.append(len(prompt)); return "AFM-OK"
fm.SystemLanguageModel = SLM; fm.LanguageModelSession = LMS
sys.modules["apple_fm_sdk"] = fm

def mac():
    initial.platform.system = lambda: "Darwin"
    initial.platform.machine = lambda: "arm64"
def lin():
    initial.platform.system = lambda: "Linux"
    initial.platform.machine = lambda: "x86_64"

fails = []
def check(name, cond, info=""):
    tag = "PASS" if cond else "FAIL"
    print(f"{tag}: {name} {info}")
    if not cond: fails.append(name)

# 1. Mac native SDK path
mac()
out = initial.summarise(DOC)
check("1 Mac native AFM", out == "AFM-OK" and PROMPT_LEN[-1] > len(DOC) * 0.9, f"(prompt {PROMPT_LEN[-1]} chars)")

# 2. Mac, SDK missing -> fm serve fallback
del sys.modules["apple_fm_sdk"]
real_import = __builtins__.__import__ if hasattr(__builtins__, "__import__") else __import__
import builtins
def no_fm(name, *a, **k):
    if name == "apple_fm_sdk": raise ImportError(name)
    return real_import(name, *a, **k)
builtins.__import__ = no_fm
seen.clear(); initial.summarise(DOC)
check("2 Mac->fm serve fallback", seen[0] == ("http://127.0.0.1:1976/v1", "system", "not-needed"), str(seen[0]))
builtins.__import__ = real_import

# 3. Mac, SDK present but model unavailable -> fallback
sys.modules["apple_fm_sdk"] = fm
class Unavailable(SLM):
    def is_available(self): return (False, "disabled by settings")
fm.SystemLanguageModel = Unavailable
seen.clear(); initial.summarise(DOC)
check("3 Mac model-unavailable fallback", seen[0][0] == "http://127.0.0.1:1976/v1")
fm.SystemLanguageModel = SLM

# 4. cloud explicit model + user key
lin(); seen.clear()
initial.summarise(DOC, model="gpt-4o-mini", api_key="sk-user")
check("4 cloud w/ user key", seen[0] == ("https://api.openai.com/v1", "gpt-4o-mini", "sk-user"), str(seen[0]))

# 5. cloud no key -> clear ValueError
try:
    initial.summarise(DOC, model="gpt-4o-mini"); check("5 no-key error", False)
except ValueError:
    check("5 no-key error raised", True)

# 6. short doc guard
try:
    initial.summarise("tiny"); check("6 short-doc guard", False)
except ValueError:
    check("6 short-doc guard raised", True)

# 7. RAG over directory (nested + skipped binary)
d = tempfile.mkdtemp()
open(os.path.join(d, "policy.txt"), "w").write(DOC)
os.makedirs(os.path.join(d, "sub"))
open(os.path.join(d, "sub", "more.md"), "w").write(DOC + " additional coverage " * 10)
open(os.path.join(d, "icon.jpg"), "w").write("binary junk")
chunks, index = initial.build_chunks(d)
check("7 dir ingestion", len(chunks) >= 2 and len(index.vs) == len(chunks), f"({len(chunks)} chunks, jpg skipped)")

# 8. ask on Mac (SDK back)
mac(); sys.modules["apple_fm_sdk"] = fm
check("8 ask RAG via AFM", initial.ask("refund?", chunks=chunks, index=index) == "AFM-OK")

# 9. main()
check("9 main()", initial.main(d, "refund?") == "AFM-OK")

# 10. env override end-to-end
os.environ["LOCAL_LLM_BASE_URL"] = "http://127.0.0.1:8080/v1"
os.environ["LOCAL_LLM_MODEL"] = "custom-model"
del sys.modules["apple_fm_sdk"]
builtins.__import__ = no_fm
seen.clear(); initial.summarise(DOC)
builtins.__import__ = real_import
check("10 LOCAL_LLM_* override honored", seen[0][:2] == ("http://127.0.0.1:8080/v1", "custom-model"), str(seen[0]))

# 11. summarise rejects non-PDF binary
try:
    initial.summarise(b"not a pdf at all"); check("11 binary guard raised", False)
except ValueError:
    check("11 binary guard raised", True)

# 12. load_contracts_from_db with temp DB (pypdf stubbed real-ish)
import sqlite3
pypdf = types.ModuleType("pypdf")
class PdfReader:
    def __init__(self, bio): self.pages = [types.SimpleNamespace(extract_text=lambda: DOC)]
pypdf.PdfReader = PdfReader
sys.modules["pypdf"] = pypdf
tdb = os.path.join(d, "test.db")
con = sqlite3.connect(tdb)
con.execute("CREATE TABLE contracts (id INTEGER PRIMARY KEY, filename TEXT, pdf_data BLOB, uploaded_at TEXT)")
con.execute("INSERT INTO contracts VALUES (7, 'c7.pdf', ?, 'now')", (b"%PDF-fake",))
con.commit(); con.close()
dbchunks = initial.load_contracts_from_db(tdb, 7)
check("12 DB contract ingestion", len(dbchunks) >= 1 and dbchunks[0]["source"] == "db:7:c7.pdf",
      f"({len(dbchunks)} chunks)")
try:
    initial.load_contracts_from_db(tdb, 999); check("12b missing id error", False)
except ValueError:
    check("12b missing id error raised", True)

# 13. .pdf files ingested via load_documents
pdfdir = os.path.join(d, "pdfs"); os.makedirs(pdfdir)
open(os.path.join(pdfdir, "x.pdf"), "wb").write(b"%PDF-fake")
pc, pi = initial.build_chunks(pdfdir)
check("13 pdf dir ingestion", len(pc) >= 1 and len(pi.vs) == len(pc), f"({len(pc)} chunks)")

# 14. persistent memory: answer cache + summary cache + revision invalidation
mac()  # route model calls through native SDK stub
r1 = initial.ask_cached("what is covered?", model="local", db_path=tdb)
r2 = initial.ask_cached("what is covered?", model="local", db_path=tdb)
check("14 ask_cached miss->hit", r1["cache"] == "miss" and r2["cache"] == "hit"
      and r1["answer"] == r2["answer"])
s1 = initial.summarise_contract_cached(7, model="local", db_path=tdb)
s2 = initial.summarise_contract_cached(7, model="local", db_path=tdb)
check("15 summary cached miss->hit", s1["cache"] == "miss" and s2["cache"] == "hit")
con = sqlite3.connect(tdb)
con.execute("INSERT INTO contracts (filename, pdf_data, uploaded_at) VALUES ('c8.pdf', ?, datetime('now'))",
            (b"%PDF-fake",))
con.commit(); con.close()
r3 = initial.ask_cached("what is covered?", model="local", db_path=tdb)
check("16 new upload invalidates cache", r3["cache"] == "miss")
# whitespace/case-insensitive question matching via normalization
r4 = initial.ask_cached("WHAT IS   COVERED?", model="local", db_path=tdb)
check("17 question normalization hits cache", r4["cache"] == "hit")

print("\nRESULT:", "ALL 17 PASSED" if not fails else f"FAILURES: {fails}")
sys.exit(1 if fails else 0)
