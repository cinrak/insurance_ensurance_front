# Piping the text box to the harness + model — snippets for the dev machine

Status (re-verified live 2026-10-17 against latest app.py, unmodified, on a copy):
## 2026-10-17 EVENING UPDATE — backend@4fff485, frontend@6e479fa
Fixed on your side: static serving (backend/static now served, GET / = 200),
upload endpoint+field corrected in UploadPage.vue source, products NULL checks
(probed: 400 "'desc' is required" / 201 works).
STILL BROKEN (probed):
  1. backend/static/ holds a STALE bundle (index-NidvYJeL.js = pre-ask build,
     only /api/upload). Rebuild (`npm run build`) and re-copy dist -> static.
  2. frontend/dist NOT rebuilt after 6e479fa: still ships /api/upload (not
     /api/contracts). Rebuild.
  3. POST /api/ask -> 405: route still absent (snippet + ask_cached below).
  4. GET /products on virgin DB -> 500 "no such table: products" — table is
     created only in POST; create it at startup.
  5. requirements.txt still Flask-only (pypdf, openai, sentence-transformers,
     faiss-cpu, numpy; add `apple_fm_sdk; platform_system=="darwin"` on the Mac).

## Older status notes (kept for reference)
- Home.vue -> POST /api/ask {question} -> reads data.answer: NOW WIRED in frontend
  and built into dist (commits 79e82c6/4d2d7ae). Contract MATCHES harness.ask exactly.
- vite.config.js now proxies /api -> Flask :5000. Good for dev mode.
- PROBE RESULTS on current app.py:
    GET  /              -> 404  (serve_static uses default app.static_folder;
                                 static/ dir does not exist — dist never mounted)
    GET  /health        -> OK
    POST /api/ask       -> 405  (no route; catch-all GET /<path:filename> matches)
    POST /api/upload    -> 405  (UploadPage sends field 'documents' here; backend
                                 only has /api/contracts + field 'file')
    POST /api/contracts -> 201  (works)
- harness -> model: verified end-to-end earlier (real pypdf+faiss+openai client).
- CONCLUSION: frontend and harness are compatible with each other; app.py needs
  the /api/ask route (below), a corrected static mount, and the /api/upload alias.
  Bonus bug: /api/products inserts NULL into NOT NULL columns when 'desc'/'value'
  are missing -> IntegrityError 500; validate or give defaults.

## 1. Flask route for app.py (paste after upload_contract)

```python
import threading

_lock = threading.Lock()
_store = None  # cached (chunks, index); invalidate after each successful upload

def _load_harness():
    import sys
    from pathlib import Path
    for cand in (Path(os.environ.get("HARNESS_DIR", "")),
                 Path(__file__).resolve().parent.parent / "harness",
                 Path("/home/link/Projects/insuranceensurance/harness")):
        if cand and (cand / "initial.py").is_file():
            sys.path.insert(0, str(cand))
            import initial
            return initial
    raise RuntimeError("harness/initial.py not found (set HARNESS_DIR)")

def _contract_store():
    global _store
    with _lock:
        if _store is None:
            h = _load_harness()
            chunks = h.load_contracts_from_db()          # reads instance/insurance.db
            _store = h.build_index_from_chunks(chunks)
        return _store

@app.route("/api/ask", methods=["POST"])
def api_ask():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    if len(question) < 3:
        return jsonify(error="Provide a 'question' in the JSON body."), 400
    kwargs = {}
    if data.get("api_key"):
        kwargs["api_key"] = data["api_key"]   # user key from frontend settings
    try:
        chunks, index = _contract_store()
        answer = _load_harness().ask(
            question, chunks=chunks, index=index,
            model=data.get("model", "auto"), **kwargs,
        )
        return jsonify(answer=answer, sources=sorted({c["source"] for c in chunks})), 200
    except Exception as e:
        return jsonify(error=str(e)), 502
```

After a successful INSERT in upload_contract, add: `global _store; _store = None`
so new contracts enter the index on the next question.

## 2. Vue text box wiring (Home.vue script + input)

```vue
<script setup>
import { ref } from 'vue'
import { useTypingEffect } from '../composables/useTypingEffect.js'

const { displayText } = useTypingEffect(['Enter a new item', 'Phone', 'Laptop', 'Desktop'])

const question = ref('')
const answer = ref('')
const loading = ref(false)
const error = ref('')

async function ask() {
  if (!question.value.trim() || loading.value) return
  loading.value = true
  error.value = ''
  answer.value = ''
  try {
    const res = await fetch('/api/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: question.value })
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`)
    answer.value = data.answer
  } catch (err) {
    error.value = err.message
  }
  loading.value = false
}
</script>
```

Template: add to the input `v-model="question" @keyup.enter="ask" :disabled="loading"`,
then a button (`@click="ask"`) and:
```html
<p v-if="loading">Thinking...</p>
<p v-if="error" class="error">{{ error }}</p>
<div v-if="answer" class="answer">{{ answer }}</div>
```

## 3. Upload mismatch (pick one side)

- Backend-friendly (no Vue change): change the decorator to
  `@app.route("/api/upload", methods=["POST"])` and read
  `request.files.getlist("documents")` (loop every file through the same insert),
  keeping `/api/contracts` + `file` as a second route for compatibility.
- Frontend-friendly: in UploadPage.vue change the fetch to '/api/contracts' and
  `formData.append('file', file)` per file, POSTing sequentially.

## 4. Dev-mode proxy (vite.config.js) so :5173 reaches Flask :5000 — DONE
Their commit 79e82c6 added exactly this; no further change needed for dev mode.

## 4b. Static-serving fix (GET / is currently 404)
`Flask(__name__)` leaves `static_folder` at a non-existent `static/`, so the new
`serve_static` route 404s everything. Fix in app.py:
```python
DIST = Path(os.environ.get("FRONTEND_DIST",
        Path(__file__).resolve().parent.parent / "insurance_ensurance_front" / "dist"))
app = Flask(__name__, static_folder=str(DIST), static_url_path="")
```
(Their `/<path:filename>` catch-all then works as-is; `index.html` at `/` already
covered by `defaults`.)

## 5. Quick fetch: use the harness persistent memory
Instead of `harness.ask(...)` in the route, prefer the cached variants — they
persist the faiss index snapshot + concise answers in `harness/.cache/`
(override dir with `HARNESS_CACHE_DIR`) and auto-invalidate when any contract
is uploaded (store-revision keyed). Same JSON contract for the frontend.
```python
result = harness.ask_cached(question)          # {"answer","sources","cache"}
# per-contract concise summary, also cached:
result = harness.summarise_contract_cached(contract_id)
```

## 6. Model config recap (harness already handles)
- Apple Silicon Mac: on-device AFM via apple_fm_sdk; fallback `fm serve` :1976.
- Any host: LOCAL_LLM_BASE_URL / LOCAL_LLM_MODEL override.
- Cloud only when the user selects a model in settings -> api_key passed through
  this route into harness.ask(...).
